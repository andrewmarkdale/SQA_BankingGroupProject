# Bank Project Phase 3
Simple banking terminal

## Steps to run scripts
   1) make clean 
   2) make
   3) chmod +x autotest.sh
   4) ./autotest.sh 
   Note: The tests will print out in the terminal and will be saved to 2 files testlog.txt and testfailures.txt. All tests working on an Ubuntu linux machine. 
   